use Sales;

select * from sales_data;

SELECT 
    COLUMN_NAME,
    DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'sales_data';

ALTER TABLE sales_data
ALTER COLUMN Date DATE;


ALTER TABLE sales_data
ALTER COLUMN Price DECIMAL(10,2);


ALTER TABLE sales_data
ALTER COLUMN Competitor_Pricing DECIMAL(10,2);


ALTER TABLE sales_data
ALTER COLUMN Category NVARCHAR(50);

ALTER TABLE sales_data
ALTER COLUMN Region NVARCHAR(50);

ALTER TABLE sales_data
ALTER COLUMN Weather_Condition NVARCHAR(30);

ALTER TABLE sales_data
ALTER COLUMN Seasonality NVARCHAR(20);

ALTER TABLE sales_data
ALTER COLUMN Epidemic BIT;


-- Total Demand
-- Measures overall market demand captured
SELECT SUM(Demand) AS Total_Demand
FROM sales_data;

-- Average Demand per SKU
SELECT AVG(Demand) AS Avg_Demand
FROM sales_data;

-- Demand Fulfillment Rate
SELECT 
    SUM(Units_Sold) * 1.0 / NULLIF(SUM(Demand), 0) 
    AS Demand_Fulfillment_Rate
FROM sales_data;

-- Price Sensitivity Index
SELECT 
    Category,
    AVG(Price) AS Avg_Price,
    AVG(Demand) AS Avg_Demand
FROM sales_data
GROUP BY Category;

-- Discount Effectiveness Ratio
SELECT 
    Discount,
    AVG(Demand) AS Avg_Demand
FROM sales_data
GROUP BY Discount
ORDER BY Discount;


-- Promotion Lift
SELECT 
    Promotion,
    AVG(Demand) AS Avg_Demand
FROM sales_data
GROUP BY Promotion;

-- Competitor Price Gap Impact
SELECT 
    AVG(Price - Competitor_Pricing) AS Avg_Price_Gap,
    AVG(Demand) AS Avg_Demand
FROM sales_data;


-- Inventory Stress Score
SELECT 
    Product_ID,
    Store_ID,
    AVG(Demand - Inventory_Level) AS Inventory_Stress_Score
FROM sales_data
GROUP BY Product_ID, Store_ID;


-- High-Risk SKU Count
SELECT COUNT(*) AS High_Risk_SKUs
FROM sales_data
WHERE (Demand - Inventory_Level) > 50;


-- Inventory Utilization Efficiency
SELECT 
    AVG(Units_Sold * 1.0 / NULLIF(Inventory_Level, 0)) 
    AS Inventory_Utilization
FROM sales_data;


-- Seasonality Demand Index
SELECT 
    Seasonality,
    AVG(Demand) AS Avg_Demand
FROM sales_data
GROUP BY Seasonality;


-- Weather Sensitivity Score
SELECT 
    Weather_Condition,
    AVG(Demand) AS Avg_Demand
FROM sales_data
GROUP BY Weather_Condition;


-- Epidemic Impact Ratio
SELECT 
    Epidemic,
    AVG(Demand) AS Avg_Demand
FROM sales_data
GROUP BY Epidemic;

-- Overstock Risk Ratio
SELECT 
    COUNT(*) * 1.0 / (SELECT COUNT(*) FROM sales_data)
    AS Overstock_Risk_Ratio
FROM sales_data
WHERE Inventory_Level > Demand;


-- Stockout Risk Ratio
SELECT 
    COUNT(*) * 1.0 / (SELECT COUNT(*) FROM sales_data)
    AS Stockout_Risk_Ratio
FROM sales_data
WHERE Demand > Inventory_Level;

SELECT
    Date,
    Product_ID,
    Category,
    Region,
    Seasonality,
    Weather_Condition,
    Epidemic,

    -- Pricing inputs
    Price,
    Competitor_Pricing,
    (Price - Competitor_Pricing) AS Price_Gap,
    Discount,
    Promotion,

    -- Demand
    Demand AS Actual_Demand,
    Demand,

    -- Business metrics
    (Price * Demand) AS Revenue,

    -- Demand sensitivity bucket (storytelling)
    CASE 
        WHEN Demand < 50 THEN 'Low'
        WHEN Demand BETWEEN 50 AND 150 THEN 'Medium'
        ELSE 'High'
    END AS Demand_Elasticity_Tag

INTO Fact_Demand_Pricing
FROM sales_data;


drop table Fact_Demand_Pricing;