import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel
from groq import Groq
import os
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from dotenv import load_dotenv
from fastapi.responses import FileResponse

load_dotenv()


#  Initialize FastAPI
app = FastAPI()



loader = PyPDFLoader("RAG_Crash_Course_Notes.pdf")
documents = loader.load()

splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50,
    separators=["\n\n", "\n", " ", ""]
)
chunks = splitter.split_documents(documents)

# Embedding model
embed_model = SentenceTransformer("all-MiniLM-L6-v2")

def get_embedding(text):
    return embed_model.encode(text, convert_to_numpy=True)

# Build FAISS index
embeddings = np.array([get_embedding(chunk.page_content) for chunk in chunks]).astype("float32")
dimension = embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(embeddings)

# Groq client
client = Groq(api_key=os.getenv("GROQ_API_KEY"))


def retrieve(query, k=3):
    query_vector = get_embedding(query).reshape(1, -1).astype("float32")
    distances, indices = index.search(query_vector, k)
    retrieved_chunks = [chunks[i].page_content for i in indices[0]]
    return retrieved_chunks

def ask_groq(question):
    context = retrieve(question)
    prompt = f"""
    Answer using ONLY the context below.
    If the answer is not in the context, say "Not found in document."

    Context:
    {context}

    Question:
    {question}
    """

    completion = client.chat.completions.create(
        model="llama-3.1-8b-instant",
        messages=[
            {"role": "system", "content": "You answer only from provided context."},
            {"role": "user", "content": prompt}
        ],
        temperature=0
    )

    return completion.choices[0].message.content


class QuestionRequest(BaseModel):
    question: str


@app.get("/")
def root():
    return {"message": "API is running successfully"}


@app.post("/ask")
def ask_question(request: QuestionRequest):
    answer = ask_groq(request.question)
    return {"answer": answer}


if __name__ == "__main__":
    uvicorn.run("main:app",host="127.0.0.1",port=8000)




