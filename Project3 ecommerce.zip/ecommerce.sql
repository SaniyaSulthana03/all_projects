﻿use ecommerce;

select * from ecommerce;

select avg(Average_Order_value),Country from ecommerce group by('Country');
select * from ecommerce where Country='India';

update ecommerce 
set Country='abcd' where Country='India';


update ecommerce
set Login_Frequency=NULL 
where Gender='Male' and City='Bangalore';

select Country,City,
DENSE_RANK() over(partition by(Country)order by Country desc),
DENSEover(partition by(City) order by city desc)
from ecommerce;


select * from ecommerce 

select age,Gender,Country from ecommerce
where Login_Frequency=
(select max(Login_Frequency) from ecommerce)
and Total_Purchases=
(select min(Total_Purchases) from ecommerce);




SELECT 
    COLUMN_NAME,
    DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME ='ecommerce_data';

select top 10 * from ecommerce_data;

SELECT *
FROM ecommerce_data
WHERE TRY_CAST(Total_Purchases AS INT) IS NULL
  AND Total_Purchases IS NOT NULL;


UPDATE ecommerce_data
SET Total_Purchases = CAST(FLOOR(TRY_CAST(Total_Purchases AS FLOAT)) AS VARCHAR)
WHERE TRY_CAST(Total_Purchases AS FLOAT) IS NOT NULL;

ALTER TABLE ecommerce_data
ALTER COLUMN Total_Purchases INT NULL;


ALTER TABLE ecommerce_data
ALTER COLUMN Signup_Quarter NVARCHAR(2) NULL;

UPDATE ecommerce_data
SET Signup_Quarter =
    CASE
        WHEN Signup_Quarter IN ('1', '1.00') THEN 'Q1'
        WHEN Signup_Quarter IN ('2', '2.00') THEN 'Q2'
        WHEN Signup_Quarter IN ('3', '3.00') THEN 'Q3'
        WHEN Signup_Quarter IN ('4', '4.00') THEN 'Q4'
        ELSE Signup_Quarter
    END;


SELECT DISTINCT Signup_Quarter
FROM ecommerce_data;


ALTER TABLE ecommerce_data
ADD Signup_Quarter_txt NVARCHAR(2);


SELECT Signup_Quarter, COUNT(*) 
FROM ecommerce_data
GROUP BY Signup_Quarter;



ALTER TABLE ecommerce_data
ALTER COLUMN Age DECIMAL(4,0);

ALTER TABLE ecommerce_data
ALTER COLUMN Membership_Years DECIMAL(4,1);

ALTER TABLE ecommerce_data
ALTER COLUMN Login_Frequency DECIMAL(4,0);

ALTER TABLE ecommerce_data
ALTER COLUMN Session_Duration_Avg DECIMAL(5,1);

ALTER TABLE ecommerce_data
ALTER COLUMN Pages_Per_Session DECIMAL(4,1);

ALTER TABLE ecommerce_data
ALTER COLUMN Cart_Abandonment_Rate DECIMAL(5,1);

ALTER TABLE ecommerce_data
ALTER COLUMN Wishlist_Items INT;

ALTER TABLE ecommerce_data
ALTER COLUMN Average_Order_Value DECIMAL(10,2);

ALTER TABLE ecommerce_data
ALTER COLUMN Days_Since_Last_Purchase DECIMAL(5,0);

ALTER TABLE ecommerce_data
ALTER COLUMN Discount_Usage_Rate DECIMAL(5,2);

ALTER TABLE ecommerce_data
ALTER COLUMN Returns_Rate DECIMAL(5,2);

ALTER TABLE ecommerce_data
ALTER COLUMN Email_Open_Rate DECIMAL(5,1);

ALTER TABLE ecommerce_data
ALTER COLUMN Customer_Service_Calls INT;

ALTER TABLE ecommerce_data
ALTER COLUMN Product_Reviews_Written INT;

ALTER TABLE ecommerce_data
ALTER COLUMN Social_Media_Engagement_Score DECIMAL(5,1);

ALTER TABLE ecommerce_data
ALTER COLUMN Mobile_App_Usage DECIMAL(5,1);

ALTER TABLE ecommerce_data
ALTER COLUMN Payment_Method_Diversity INT;

ALTER TABLE ecommerce_data
ALTER COLUMN Lifetime_Value DECIMAL(12,2);

ALTER TABLE ecommerce_data
ALTER COLUMN Credit_Balance DECIMAL(12,2);


select * from ecommerce_data;

USE ecommerce;

-- 1?? Business logic rules
UPDATE ecommerce_data
SET Average_Order_Value = 0,
    Discount_Usage_Rate = 0,
    Days_Since_Last_Purchase = 9999
WHERE Total_Purchases = 0;

UPDATE ecommerce_data
SET Wishlist_Items = 0
WHERE Wishlist_Items IS NULL;

UPDATE ecommerce_data
SET Customer_Service_Calls = 0
WHERE Customer_Service_Calls IS NULL;

UPDATE ecommerce_data
SET Product_Reviews_Written = 0
WHERE Total_Purchases = 0 OR Product_Reviews_Written IS NULL;

--UPDATE ecommerce_data
--SET Session_Duration_Avg = 0,
  --  Mobile_App_Usage = 0,
    --Social_Media_Engagement_Score = 0,
   -- Email_Open_Rate = 0
-- WHERE Login_Frequency = 0 OR Login_Frequency IS NULL;

-- 2?? Fill remaining NULLs with median/mean
DECLARE @MedianAge FLOAT;
SELECT @MedianAge = PERCENTILE_CONT(0.5)
                    WITHIN GROUP (ORDER BY Age)
                    OVER ()
FROM ecommerce_data
WHERE Age IS NOT NULL;
SET @MedianAge = (SELECT DISTINCT @MedianAge);

UPDATE ecommerce_data
SET Age = @MedianAge
WHERE Age IS NULL;

-- Example for mean
DECLARE @AvgSession FLOAT;
SELECT @AvgSession = AVG(Session_Duration_Avg)
FROM ecommerce_data
WHERE Session_Duration_Avg IS NOT NULL;

UPDATE ecommerce_data
SET Session_Duration_Avg = @AvgSession
WHERE Session_Duration_Avg IS NULL;

-- Pages_Per_Session
UPDATE ecommerce_data
SET Pages_Per_Session = (
    SELECT AVG(Pages_Per_Session)
    FROM ecommerce_data
    WHERE Pages_Per_Session IS NOT NULL
)
WHERE Pages_Per_Session IS NULL;

-- Email_Open_Rate
UPDATE ecommerce_data
SET Email_Open_Rate = (
    SELECT AVG(Email_Open_Rate)
    FROM ecommerce_data
    WHERE Email_Open_Rate IS NOT NULL
)
WHERE Email_Open_Rate IS NULL;

-- Social_Media_Engagement_Score
UPDATE ecommerce_data
SET Social_Media_Engagement_Score = (
    SELECT AVG(Social_Media_Engagement_Score)
    FROM ecommerce_data
    WHERE Social_Media_Engagement_Score IS NOT NULL
)
WHERE Social_Media_Engagement_Score IS NULL;

-- Mobile_App_Usage
UPDATE ecommerce_data
SET Mobile_App_Usage = (
    SELECT AVG(Mobile_App_Usage)
    FROM ecommerce_data
    WHERE Mobile_App_Usage IS NOT NULL
)
WHERE Mobile_App_Usage IS NULL;

-- Credit_Balance
UPDATE ecommerce_data
SET Credit_Balance = (
    SELECT AVG(Credit_Balance)
    FROM ecommerce_data
    WHERE Credit_Balance IS NOT NULL
)
WHERE Credit_Balance IS NULL;

DECLARE @Median_Payment_Method FLOAT;

SELECT DISTINCT
    @Median_Payment_Method =
    PERCENTILE_CONT(0.5)
    WITHIN GROUP (ORDER BY Payment_Method_Diversity)
    OVER ()
FROM ecommerce_data
WHERE Payment_Method_Diversity IS NOT NULL;

UPDATE ecommerce_data
SET Payment_Method_Diversity = @Median_Payment_Method
WHERE Payment_Method_Diversity IS NULL;


SELECT
    COUNT(*) AS Total_Rows,
    SUM(CASE WHEN Pages_Per_Session IS NULL THEN 1 ELSE 0 END) AS Pages_Null,
    SUM(CASE WHEN Discount_Usage_Rate IS NULL THEN 1 ELSE 0 END) AS Discount_Null,
    SUM(CASE WHEN Returns_Rate IS NULL THEN 1 ELSE 0 END) AS Returns_Null,
    SUM(CASE WHEN Email_Open_Rate IS NULL THEN 1 ELSE 0 END) AS Email_Null,
    SUM(CASE WHEN Social_Media_Engagement_Score IS NULL THEN 1 ELSE 0 END) AS Social_Null,
    SUM(CASE WHEN Mobile_App_Usage IS NULL THEN 1 ELSE 0 END) AS Mobile_Null,
    SUM(CASE WHEN Payment_Method_Diversity IS NULL THEN 1 ELSE 0 END) AS Payment_Null,
    SUM(CASE WHEN Credit_Balance IS NULL THEN 1 ELSE 0 END) AS Credit_Null
FROM ecommerce_data;





UPDATE ecommerce_data
SET Discount_Usage_Rate = (
    SELECT AVG(Discount_Usage_Rate)
    FROM ecommerce_data
    WHERE Discount_Usage_Rate IS NOT NULL
      AND Total_Purchases > 0
)
WHERE Discount_Usage_Rate IS NULL
  AND Total_Purchases > 0;


UPDATE ecommerce_data
SET Returns_Rate = (
    SELECT AVG(Returns_Rate)
    FROM ecommerce_data
    WHERE Returns_Rate IS NOT NULL
      AND Total_Purchases > 0
)
WHERE Returns_Rate IS NULL
  AND Total_Purchases > 0;


SELECT
    SUM(CASE WHEN Age IS NULL THEN 1 ELSE 0 END) AS Age_Nulls,
    SUM(CASE WHEN Gender IS NULL THEN 1 ELSE 0 END) AS Gender_Nulls,
    SUM(CASE WHEN Country IS NULL THEN 1 ELSE 0 END) AS Country_Nulls,
    SUM(CASE WHEN City IS NULL THEN 1 ELSE 0 END) AS City_Nulls,

    SUM(CASE WHEN Membership_Years IS NULL THEN 1 ELSE 0 END) AS Membership_Years_Nulls,
    SUM(CASE WHEN Login_Frequency IS NULL THEN 1 ELSE 0 END) AS Login_Frequency_Nulls,
    SUM(CASE WHEN Session_Duration_Avg IS NULL THEN 1 ELSE 0 END) AS Session_Duration_Nulls,
    SUM(CASE WHEN Pages_Per_Session IS NULL THEN 1 ELSE 0 END) AS Pages_Per_Session_Nulls,

    SUM(CASE WHEN Cart_Abandonment_Rate IS NULL THEN 1 ELSE 0 END) AS Cart_Abandonment_Nulls,
    SUM(CASE WHEN Wishlist_Items IS NULL THEN 1 ELSE 0 END) AS Wishlist_Items_Nulls,
    SUM(CASE WHEN Total_Purchases IS NULL THEN 1 ELSE 0 END) AS Total_Purchases_Nulls,
    SUM(CASE WHEN Average_Order_Value IS NULL THEN 1 ELSE 0 END) AS AOV_Nulls,

    SUM(CASE WHEN Days_Since_Last_Purchase IS NULL THEN 1 ELSE 0 END) AS Days_Since_Last_Purchase_Nulls,
    SUM(CASE WHEN Discount_Usage_Rate IS NULL THEN 1 ELSE 0 END) AS Discount_Usage_Nulls,
    SUM(CASE WHEN Returns_Rate IS NULL THEN 1 ELSE 0 END) AS Returns_Rate_Nulls,
    SUM(CASE WHEN Email_Open_Rate IS NULL THEN 1 ELSE 0 END) AS Email_Open_Rate_Nulls,

    SUM(CASE WHEN Customer_Service_Calls IS NULL THEN 1 ELSE 0 END) AS CS_Calls_Nulls,
    SUM(CASE WHEN Product_Reviews_Written IS NULL THEN 1 ELSE 0 END) AS Reviews_Nulls,
    SUM(CASE WHEN Social_Media_Engagement_Score IS NULL THEN 1 ELSE 0 END) AS Social_Media_Nulls,
    SUM(CASE WHEN Mobile_App_Usage IS NULL THEN 1 ELSE 0 END) AS Mobile_App_Nulls,

    SUM(CASE WHEN Payment_Method_Diversity IS NULL THEN 1 ELSE 0 END) AS Payment_Method_Nulls,
    SUM(CASE WHEN Lifetime_Value IS NULL THEN 1 ELSE 0 END) AS Lifetime_Value_Nulls,
    SUM(CASE WHEN Credit_Balance IS NULL THEN 1 ELSE 0 END) AS Credit_Balance_Nulls,
    SUM(CASE WHEN Churned IS NULL THEN 1 ELSE 0 END) AS Churned_Nulls,
    SUM(CASE WHEN Signup_Quarter IS NULL THEN 1 ELSE 0 END) AS Signup_Quarter_Nulls
FROM ecommerce_data;


ALTER TABLE ecommerce_data
ADD Has_Purchased BIT;

UPDATE ecommerce_data
SET Has_Purchased = CASE 
    WHEN Total_Purchases > 0 THEN 1 
    ELSE 0 
END;


UPDATE ecommerce_data
SET Discount_Usage_Rate = (
    SELECT AVG(Discount_Usage_Rate)
    FROM ecommerce_data
    WHERE Discount_Usage_Rate IS NOT NULL
)
WHERE Discount_Usage_Rate IS NULL
  AND Total_Purchases > 0;



SELECT
    Has_Purchased,
    COUNT(*) AS Customers,
    SUM(CASE WHEN Days_Since_Last_Purchase IS NULL THEN 1 ELSE 0 END) AS Days_Nulls
FROM ecommerce_data
GROUP BY Has_Purchased;




  UPDATE ecommerce_data
SET Discount_Usage_Rate = 0
WHERE Total_Purchases = 0;



-- No purchases → no returns
UPDATE ecommerce_data
SET Returns_Rate = 0
WHERE Total_Purchases = 0;

-- Purchases exist but missing return rate
UPDATE ecommerce_data
SET Returns_Rate = (
    SELECT AVG(Returns_Rate)
    FROM ecommerce_data
    WHERE Returns_Rate IS NOT NULL
)
WHERE Returns_Rate IS NULL
  AND Total_Purchases > 0;

SELECT
    SUM(CASE WHEN Days_Since_Last_Purchase IS NULL THEN 1 ELSE 0 END) AS Days_Since_Last_Purchase_Nulls,
    SUM(CASE WHEN Discount_Usage_Rate IS NULL THEN 1 ELSE 0 END) AS Discount_Nulls,
    SUM(CASE WHEN Returns_Rate IS NULL THEN 1 ELSE 0 END) AS Returns_Nulls
FROM ecommerce_data;


select * from ecommerce_data where Login_Frequency=0;




UPDATE ecommerce_data
SET Discount_Usage_Rate = (
    SELECT AVG(Discount_Usage_Rate)
    FROM ecommerce_data
    WHERE Discount_Usage_Rate IS NOT NULL
)
WHERE Discount_Usage_Rate IS NULL;


UPDATE ecommerce_data
SET Returns_Rate = (
    SELECT AVG(Returns_Rate)
    FROM ecommerce_data
    WHERE Returns_Rate IS NOT NULL
)
WHERE Returns_Rate IS NULL;


ALTER TABLE ecommerce_data
ADD Invalid_Purchase_Flag BIT;

UPDATE ecommerce_data
SET Invalid_Purchase_Flag = 1
WHERE Total_Purchases = 0
  AND Discount_Usage_Rate = 0
  AND Returns_Rate = 0;


SELECT COUNT(*)
FROM ecommerce_data
WHERE Total_Purchases = 0;


SELECT
    COUNT(*) AS Total_Rows,
    SUM(CASE WHEN Days_Since_Last_Purchase IS NULL THEN 1 ELSE 0 END) AS Days_Nulls,
    SUM(CASE WHEN Total_Purchases = 0 THEN 1 ELSE 0 END) AS Zero_Purchases
FROM ecommerce_data;



UPDATE ecommerce_data
SET Days_Since_Last_Purchase = NULL
WHERE Total_Purchases = 0;


DECLARE @Median_Days FLOAT;

SELECT @Median_Days =
    PERCENTILE_CONT(0.5)
    WITHIN GROUP (ORDER BY Days_Since_Last_Purchase)
    OVER ()
FROM ecommerce_data
WHERE Total_Purchases > 0
  AND Days_Since_Last_Purchase IS NOT NULL;


UPDATE ecommerce_data
SET Days_Since_Last_Purchase = @Median_Days
WHERE Total_Purchases > 0
AND Days_Since_Last_Purchase IS NULL;


SELECT
    CASE WHEN Total_Purchases > 0 THEN 1 ELSE 0 END AS Has_Purchased,
    COUNT(*) AS Customers,
    SUM(CASE WHEN Days_Since_Last_Purchase IS NULL THEN 1 ELSE 0 END) AS Days_Nulls
FROM ecommerce_data
GROUP BY CASE WHEN Total_Purchases > 0 THEN 1 ELSE 0 END;


UPDATE ecommerce_data
SET Days_Since_Last_Purchase = NULL
WHERE Total_Purchases = 0;

SELECT
    CASE WHEN Total_Purchases > 0 THEN 1 ELSE 0 END AS Has_Purchased,
    COUNT(*) AS Customers,
    SUM(CASE WHEN Days_Since_Last_Purchase IS NULL THEN 1 ELSE 0 END) AS Days_Nulls
FROM ecommerce_data
GROUP BY CASE WHEN Total_Purchases > 0 THEN 1 ELSE 0 END;


SELECT 
    Total_Purchases,
    Days_Since_Last_Purchase
FROM ecommerce_data
WHERE Total_Purchases = 0;


SELECT 
    COUNT(*) AS Total_Zero_Purchase_Customers,
    SUM(CASE WHEN Days_Since_Last_Purchase IS NULL THEN 1 ELSE 0 END) AS True_NULLs,
    SUM(CASE WHEN Days_Since_Last_Purchase IS NOT NULL THEN 1 ELSE 0 END) AS Not_NULLs
FROM ecommerce_data
WHERE Total_Purchases = 0;


UPDATE ecommerce_data
SET Days_Since_Last_Purchase = NULL
WHERE Total_Purchases = 0
 AND Days_Since_Last_Purchase IS NOT NULL;SELECT
    CASE WHEN Total_Purchases = 0 THEN 'No Purchase' ELSE 'Purchased' END AS Customer_Type,
    COUNT(*) AS Customers,
    SUM(CASE WHEN Days_Since_Last_Purchase IS NULL THEN 1 ELSE 0 END) AS NULL_Count
FROM ecommerce_data
GROUP BY CASE WHEN Total_Purchases = 0 THEN 'No Purchase' ELSE 'Purchased' END;



DECLARE @MedianDays FLOAT;

SELECT @MedianDays =
PERCENTILE_CONT(0.5) 
WITHIN GROUP (ORDER BY Days_Since_Last_Purchase)
OVER ()
FROM ecommerce_data
WHERE Total_Purchases > 0
  AND Days_Since_Last_Purchase IS NOT NULL;

UPDATE ecommerce_data
SET Days_Since_Last_Purchase = @MedianDays
WHERE Total_Purchases > 0
  AND Days_Since_Last_Purchase IS NULL;


SELECT
    CASE WHEN Total_Purchases = 0 THEN 'No Purchase' ELSE 'Purchased' END AS Customer_Type,
    COUNT(*) AS Customers,
    SUM(CASE WHEN Days_Since_Last_Purchase IS NULL THEN 1 ELSE 0 END) AS NULL_Count
FROM ecommerce_data
GROUP BY CASE WHEN Total_Purchases = 0 THEN 'No Purchase' ELSE 'Purchased' END;

-- Total Customers  --  How big is our customer base?
-- “We currently serve 50,000 customers, which forms the baseline for all revenue, churn, and engagement analysis.”
SELECT COUNT(*) AS Total_Customers
FROM ecommerce_data;

-- Churn Rate  --  How many customers are we losing?
-- “Our churn rate of X% shows how effectively we are retaining customers and highlights the urgency of retention strategies.”
SELECT 
    CAST(SUM(CASE WHEN Churned = 1 THEN 1 ELSE 0 END) * 100.0 
         / COUNT(*) AS DECIMAL(5,2)) AS Churn_Rate
FROM ecommerce_data;

-- Average Login Frequency  -- How frequently do users interact with the platform?
-- Customers log in X times per month, showing how regularly the platform is part of their routine.”
SELECT AVG(Login_Frequency) AS Avg_Login_Frequency
FROM ecommerce_data;

-- Are users deeply engaged or just visiting briefly?
-- “Users spend X minutes per session and view Y pages, indicating how engaging and intuitive the platform experience is.”
SELECT 
    AVG(Session_Duration_Avg) AS Avg_Session_Duration,
    AVG(Pages_Per_Session) AS Avg_Pages_Per_Session
FROM ecommerce_data;

-- Purchase Conversion Rate  -- How many customers actually buy?
-- “Only X% of users convert into buyers, revealing a gap between engagement and monetization.”
SELECT 
    CAST(SUM(CASE WHEN Total_Purchases > 0 THEN 1 ELSE 0 END) * 100.0 
         / COUNT(*) AS DECIMAL(5,2)) AS Purchase_Conversion_Rate
FROM ecommerce_data;

-- Average Order Value (AOV) -- How much revenue does each order generate?
-- “The average order value of ₹X indicates strong upsell potential per transaction.”
SELECT 
    AVG(Average_Order_Value) AS AOV
FROM ecommerce_data
WHERE Total_Purchases > 0;


-- Customer Lifetime Value  --  How valuable is a customer over time?
-- “Customers generate ₹X lifetime value, guiding marketing spend and loyalty investments.”
SELECT AVG(Lifetime_Value) AS Avg_CLV
FROM ecommerce_data
WHERE Total_Purchases > 0;



-- Cart Abandonment Rate  -- Where are customers dropping before purchase?
-- “A cart abandonment rate of X% highlights checkout friction and lost revenue opportunities.”
SELECT AVG(Cart_Abandonment_Rate) AS Avg_Cart_Abandonment
FROM ecommerce_data;


-- Recency -- How recently did customers transact?
-- “Customers last purchased X days ago on average, helping identify churn-risk segments.”
SELECT AVG(Days_Since_Last_Purchase) AS Avg_Recency
FROM ecommerce_data
WHERE Total_Purchases > 0;


-- Discount Dependency  -- Are customers price-sensitive?
-- “High discount usage indicates price sensitivity and margin pressure.”
SELECT 
    AVG(Discount_Usage_Rate) AS Avg_Discount_Usage
FROM ecommerce_data
WHERE Total_Purchases > 0
  AND Discount_Usage_Rate IS NOT NULL;



-- Support Load  -- Are customers facing post-purchase issues?
-- “Higher support calls correlate strongly with dissatisfaction and churn.”
SELECT 
    AVG(Customer_Service_Calls) AS Avg_Support_Calls
FROM ecommerce_data
WHERE Total_Purchases > 0;


-- Repeat Purchase Rate  -- Customers who purchased more than once
-- “Shows what % of our customers make repeat purchases. High repeat purchase rates indicate strong loyalty and reduced marketing acquisition cost.”
SELECT 
    CAST(SUM(CASE WHEN Total_Purchases > 1 THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS Repeat_Purchase_Rate
FROM ecommerce_data;


-- Wishlist-to-Purchase Gap  -- Wishlist items vs purchases ratio
-- High wishlist-to-purchase ratio signals interest without conversion—possible friction in pricing, stock, or UX.
SELECT 
    AVG(CASE WHEN Total_Purchases > 0 THEN Wishlist_Items / Total_Purchases ELSE NULL END) AS Wishlist_to_Purchase_Ratio
FROM ecommerce_data;


-- Recency Risk Index
-- Identifies customers at risk of churn. Higher recency = longer inactivity = higher churn probability.
SELECT AVG(Days_Since_Last_Purchase) AS Avg_Recency
FROM ecommerce_data
WHERE Total_Purchases > 0;


-- Returns Risk Rate
SELECT AVG(Returns_Rate) AS Avg_Returns_Rate
FROM ecommerce_data
WHERE Total_Purchases > 0;


-- Support Load Index
SELECT AVG(Customer_Service_Calls) AS Avg_Support_Calls
FROM ecommerce_data;

SELECT AVG(Payment_Method_Diversity) AS Avg_Payment_Methods
FROM ecommerce_data;

-- Customer Voice Score
SELECT AVG(Product_Reviews_Written) AS Avg_Reviews
FROM ecommerce_data;









