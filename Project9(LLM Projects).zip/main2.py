from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import FileResponse
from fastapi.concurrency import run_in_threadpool
from fastapi import HTTPException
import shutil
import os
import uvicorn

from mic import transcribe_audio
# from tts1 import text_to_speech
from ocr import extract_text_from_image
from text_summarization import summarize_text_with_rag

app = FastAPI(title="Multimodal AI API", version="1.0")

os.makedirs("outputs", exist_ok=True)


@app.get("/")
def home():
    return {"message": "Multimodal AI API running"}


@app.post("/stt")
async def speech_to_text(file: UploadFile = File(...)):
    path = f"outputs/{file.filename}"

    with open(path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    transcription = transcribe_audio(path)

    return {"transcription": transcription}


# @app.post("/tts")
# async def tts_api(text: str = Form(...)):
#     audio_path = text_to_speech(text)
#     return {"audio_file": audio_path}

# @app.post("/tts")
# async def tts_api(text: str = Form(...)):
#     try:
#         from tts1 import text_to_speech  # 👈 import HERE (not top)

#         audio_path = await run_in_threadpool(text_to_speech, text)
#         return {"audio_file": audio_path}

#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))

@app.post("/tts")
async def tts_api(text: str = Form(...)):
    from tts1 import text_to_speech

    audio_path = await run_in_threadpool(text_to_speech, text)

    return FileResponse(
        audio_path,
        media_type="audio/mpeg",
        filename=os.path.basename(audio_path)
    )


@app.post("/ocr")
async def ocr_api(file: UploadFile = File(...)):
    image_path = f"temp/{file.filename}"

    with open(image_path, "wb") as f:
        f.write(await file.read())

    summary = extract_text_from_image(image_path)
    return {"summary": summary}



@app.post("/rag")
async def rag(file: UploadFile = File(...)):
    os.makedirs("outputs", exist_ok=True)

    path = f"outputs/{file.filename}"

    with open(path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    summary = await run_in_threadpool(summarize_text_with_rag, path)

    return {"summary": summary}


# @app.get("/audio/{filename}")
# def get_audio(filename: str):
#     path = f"outputs/{filename}"
#     return FileResponse(path, media_type="audio/wav")

if __name__ == "__main__":
    uvicorn.run("main2:app", host="127.0.0.1", port=8000, reload=True)